# export AETHERUI=dev-test-20260814.000
export AETHERUI=dev-20261027.000
# export AETHERUI_V1=demo-20250524.005
export AETHERUI_V1=dev-20261027.000
#export AETHERMIDDLEWARE=vb-20250622.000
export AETHERMIDDLEWARE=dev-20261027.000
export AETHERPYTHONAPI=dev-20261026.001
export AGENTCONFIG=dev-20261026.006
export AGENTSTUDIO_WEBSOCKET=dev-20261030.001
export AGENTSTUDIO_WEBSOCKET_V2=dev-20260522.000
export RAG_EVALUATOR_ML=master-20261103.000
export CODE_EXPORT=dev-20260310.001
##export MODEL_TUNING=orion-qa-20250909.003    #dev-20250530.009
export MODEL_TUNING=dev-20250530.009
export ED_MODEL_INFERENCE=dev-20250721.004
export MCP_SERVER=dev-20260922.000
export MCP_STANDARD_SERVER=dev-20260922.000
export TNEUSECASEUI=dev-20251009.003
export AGENTONBOARDING_API=dev-20251125.001
export ORIONCHATUI=dev-20260717.003
export EXPORT_PROJECT=orion-export-project-20260525.000
export ITSM_ADAPTER=container-20260603.006
export ORION_ITSM_ADAPTER=container-20260602.000
export CHATOPS_MIDDLEWARE=aws-dev-20260602.000
export NEMOCLAW=nemoclaw-dev-20260622.009
export LOG_TRACEABILITY_MIDDLEWARE=dev-20261023.000
export ORION_OBSERVATORY_UI=orion-observatory-dev-20261023.002
export ITSM_ADAPTER_MIDDLEWARE=feature-20250214.2020
export ITSM_ADAPTER=container-20260602.000
export LICENSE_VERIFIER=dev-20260813.000
export LICENSE_MANAGER_UI=feature-20260901.001
export LICENSE_MANAGER_MIDDLEWARE=feature-20260901.005
export AGENTSPHERE=orion-agentsphere-dev-20261027.005

sed "s/\$AETHERUI/$AETHERUI/" aether/aether-ui/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/aether-ui/svc.yaml

sed "s/\$AETHERUI_V1/$AETHERUI_V1/" aether/aether-ui-v1/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/aether-ui-v1/svc.yaml

sed "s/\$AETHERMIDDLEWARE/$AETHERMIDDLEWARE/" aether/aether-middleware/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/aether-middleware/svc.yaml

sed "s/\$AETHERPYTHONAPI/$AETHERPYTHONAPI/" aether/aether-python-api/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/aether-python-api/svc.yaml

sed "s/\$AGENTCONFIG/$AGENTCONFIG/" aether/mgmt-ai-agentconfig/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/mgmt-ai-agentconfig/svc.yaml

sed "s/\$AGENTSTUDIO_WEBSOCKET/$AGENTSTUDIO_WEBSOCKET/" aether/mgmt-ai-agentstudio-websocket/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/mgmt-ai-agentstudio-websocket/svc.yaml

sed "s/\$AGENTSPHERE/$AGENTSPHERE/" aether/mgmt-ai-agentsphere/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/mgmt-ai-agentsphere/svc.yaml

sed "s/\$AGENTSTUDIO_WEBSOCKET_V2/$AGENTSTUDIO_WEBSOCKET_V2/" aether/mgmt-ai-agentstudio-websocket-v2/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/mgmt-ai-agentstudio-websocket-v2/svc.yaml

sed "s/\$RAG_EVALUATOR_ML/$RAG_EVALUATOR_ML/" aether/mgmt-ai-rag-evaluator-ml/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/mgmt-ai-rag-evaluator-ml/svc.yaml

sed "s/\$CODE_EXPORT/$CODE_EXPORT/" aether/mgmt-ai-teno-code-export/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/mgmt-ai-teno-code-export/svc.yaml

sed "s/\$MODEL_TUNING/$MODEL_TUNING/" aether/mgmt-ai-teno-model-finetuning/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/mgmt-ai-teno-model-finetuning/svc.yaml

sed "s/\$ED_MODEL_INFERENCE/$ED_MODEL_INFERENCE/" aether/mgmt-ai-teno-ed-model-inference/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/mgmt-ai-teno-ed-model-inference/svc.yaml

sed "s/\$MCP_SERVER/$MCP_SERVER/" aether/mgmt-ai-mcp-server/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/mgmt-ai-mcp-server/svc.yaml

sed "s/\$MCP_STANDARD_SERVER/$MCP_STANDARD_SERVER/" aether/mgmt-ai-standard-mcp-server/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/mgmt-ai-standard-mcp-server/svc.yaml

sed "s/\$TNEUSECASEUI/$TNEUSECASEUI/" aether/tne-usecase-ui/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/tne-usecase-ui/svc.yaml

sed "s/\$AGENTONBOARDING_API/$AGENTONBOARDING_API/" aether/aether-mgmt-ai-agentonboarding-api/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/aether-mgmt-ai-agentonboarding-api/svc.yaml

sed "s/\$ORIONCHATUI/$ORIONCHATUI/" aether/orion-apps-ui/mgmt-ai-orion-chat-ui-deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/orion-apps-ui/mgmt-ai-orion-chat-ui-svc.yaml

sed "s/\$EXPORT_PROJECT/$EXPORT_PROJECT/" aether/export-project/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/export-project/svc.yaml

sed "s/\$CHATOPS_MIDDLEWARE/$CHATOPS_MIDDLEWARE/" aether/mgmt-ai-orion-chat-console-middleware/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/mgmt-ai-orion-chat-console-middleware/svc.yaml

sed "s/\$ITSM_ADAPTER/$ITSM_ADAPTER/" aether/mgmt-ai-opscopilt-itsm-adapter/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/mgmt-ai-opscopilt-itsm-adapter/svc.yaml

sed "s/\$ORION_ITSM_ADAPTER/$ORION_ITSM_ADAPTER/" aether/mgmt-ai-orion-itsm-adapter/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/mgmt-ai-orion-itsm-adapter/svc.yaml

sed "s/\$ITSM_ADAPTER_MIDDLEWARE/$ITSM_ADAPTER_MIDDLEWARE/" aether/itsm-adapter-middleware/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/itsm-adapter-middleware/svc.yaml

sed "s/\$NEMOCLAW/$NEMOCLAW/" aether/nemoclaw/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/nemoclaw/svc.yaml

sed "s/\$LOG_TRACEABILITY_MIDDLEWARE/$LOG_TRACEABILITY_MIDDLEWARE/" aether/logging-traceability-middleware/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/logging-traceability-middleware/svc.yaml

sed "s/\$ORION_OBSERVATORY_UI/$ORION_OBSERVATORY_UI/" aether/orion-observatory-ui/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/orion-observatory-ui/svc.yaml
# kubectl apply -f aether/orion-observatory-ui/rbac.yaml
# kubectl apply -f aether/orion-observatory-ui/rbac-check-pod.yaml

sed "s/\$LICENSE_VERIFIER/$LICENSE_VERIFIER/" aether/orion-license-verifier/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/orion-license-verifier/svc.yaml

sed "s/\$LICENSE_MANAGER_UI/$LICENSE_MANAGER_UI/" aether/mgmt-ai-orion-license-manager-ui/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/mgmt-ai-orion-license-manager-ui/svc.yaml

sed "s/\$LICENSE_MANAGER_MIDDLEWARE/$LICENSE_MANAGER_MIDDLEWARE/" aether/mgmt-ai-license-manager-middleware/deployment.yaml  | kubectl apply -f -
kubectl apply -f aether/mgmt-ai-license-manager-middleware/svc.yaml

kubectl apply -f aether/aether-ui-ingress.yaml
kubectl apply -f aether/aether-ui-v1-ingress.yaml
kubectl apply -f aether/aether-ws-ingress.yaml
kubectl apply -f aether/aether-ws-ingress-v2.yaml
kubectl apply -f aether/aether-mc-ui-ingress.yaml
kubectl apply -f aether/aether-chat-ui-ingress.yaml
kubectl apply -f aether/aether-export-project-ingress.yaml
kubectl apply -f aether/orion-observatory-ui-ingress.yaml
kubectl apply -f aether/orion-license-manager-ingress.yaml
sleep 60s
kubectl get pods -n aether 
