# Script to configure WSO2 truststore with signing(signing.p12) and TLS certificates(tls.p12)
# this script will be passed to WSO2 container at runtime as specified in the dockerfile

# !/bin/sh
set -eu
SEC="${WSO2_SERVER_HOME}/repository/resources/security"
cp /keys/signing.p12 /keys/tls.p12 "$SEC/"
# delete existing certificate with alias wso2carbon and import the new signing certificate
keytool -delete -alias wso2carbon -keystore "$SEC/client-truststore.p12" -storepass wso2carbon >/dev/null 2>&1 || true
keytool -importcert -noprompt -alias wso2carbon -file /keys/signing.crt -keystore "$SEC/client-truststore.p12" -storepass wso2carbon >/dev/null 

# delete existing certificate with alias wso2-trust and import the new TLS certificate
keytool -delete -alias wso2-trust -keystore "$SEC/client-truststore.p12" -storepass wso2carbon >/dev/null 2>&1 || true
keytool -importcert -noprompt -alias wso2-trust -file /trust/wso2-trust.pem -keystore "$SEC/client-truststore.p12" -storepass wso2carbon >/dev/null
exec /home/wso2carbon/docker-entrypoint.sh "$@"


# keytool - java utility tool, being used inside wso2 conatiner to manage truststore certificates
# # simple format: keytool -importcert \
#   -alias rds-ca \
#   -file global-bundle.pem \
#   -keystore client-truststore.jks
# Trust your certificate (or its CA), for calls from WSO2 to other services that use it