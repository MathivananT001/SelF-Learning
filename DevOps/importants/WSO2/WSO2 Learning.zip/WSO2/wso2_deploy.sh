kubectl apply -f configmap-db_ca.yaml
kubectl apply -f configmap-wso2-trust.yaml
kubectl apply -f ingress.yaml
kubectl apply -f secrets.yaml
kubectl apply -f wso2is-config.yaml
kubectl apply -f deployment.yaml
